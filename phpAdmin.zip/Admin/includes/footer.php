<footer class="footer-area bg-white text-center rounded-top-10">
                <p class="fs-14">© <span class="text-primary">Admin</span> is Proudly Owned by <a
                        href="#" target="_blank" class="text-decoration-none">Kunal</a></p>
            </footer>